/* ============================================================
   MERIDIAN — Product data
   One source of truth for every watch. Swap "image" paths for
   your own photos (recommended size: square, 1000x1000+).
   ============================================================ */

const PRODUCTS = [
  {
    id: 1,
    name: "Noir Automatic",
    category: "Automatic",
    price: 420,
    rating: 5,
    reviews: 46,
    image: "assets/images/watch-1.svg",
    tagline: "The everyday flagship — black dial, gold detailing.",
    description:
      "The Noir Automatic pairs a deep matte-black dial with warm brass-gold indices for a piece that moves effortlessly from the office to the evening. A self-winding movement means it never needs a battery — just wear it.",
    specs: [
      { label: "Case Diameter", value: "40 mm" },
      { label: "Movement", value: "Automatic, 42h reserve" },
      { label: "Water Resistance", value: "50 m" },
      { label: "Strap", value: "Genuine leather, brown" },
      { label: "Glass", value: "Sapphire crystal" }
    ]
  },
  {
    id: 2,
    name: "Ivory Steel",
    category: "Quartz",
    price: 360,
    rating: 4,
    reviews: 31,
    image: "assets/images/watch-2.svg",
    tagline: "Light, clean and endlessly wearable.",
    description:
      "A cream dial set inside a brushed-steel case, built for people who like their accessories quiet. The Ivory Steel favours restraint over statement — thin markers, a slim profile, and a bracelet that catches the light without shouting.",
    specs: [
      { label: "Case Diameter", value: "38 mm" },
      { label: "Movement", value: "Precision quartz" },
      { label: "Water Resistance", value: "30 m" },
      { label: "Strap", value: "Stainless steel bracelet" },
      { label: "Glass", value: "Mineral crystal" }
    ]
  },
  {
    id: 3,
    name: "Onyx Sport",
    category: "Quartz",
    price: 310,
    rating: 4,
    reviews: 58,
    image: "assets/images/watch-3.svg",
    tagline: "Built for movement, styled for everything else.",
    description:
      "A tougher case profile and a soft-touch strap make the Onyx Sport the pick for daily wear. Silver markers stay legible in low light, and the reinforced crown keeps dust and moisture out on active days.",
    specs: [
      { label: "Case Diameter", value: "42 mm" },
      { label: "Movement", value: "Precision quartz" },
      { label: "Water Resistance", value: "100 m" },
      { label: "Strap", value: "Silicone, black" },
      { label: "Glass", value: "Scratch-resistant mineral" }
    ]
  },
  {
    id: 4,
    name: "Gold Reserve",
    category: "Automatic",
    price: 580,
    rating: 5,
    reviews: 22,
    image: "assets/images/watch-4.svg",
    tagline: "The occasion piece — full gold hardware.",
    description:
      "Our most dressed-up reference: a gold-toned case and strap surrounding a black sunburst dial. The Gold Reserve is built for the nights that call for a little more — weddings, galas, closing a deal.",
    specs: [
      { label: "Case Diameter", value: "40 mm" },
      { label: "Movement", value: "Automatic, 46h reserve" },
      { label: "Water Resistance", value: "30 m" },
      { label: "Strap", value: "Gold-tone stainless steel" },
      { label: "Glass", value: "Sapphire crystal" }
    ]
  },
  {
    id: 5,
    name: "Blanc Heritage",
    category: "Automatic",
    price: 495,
    rating: 5,
    reviews: 39,
    image: "assets/images/watch-5.svg",
    tagline: "A tribute to the archive dress watch.",
    description:
      "White dial, gold case, warm leather strap — the Blanc Heritage borrows its proportions from classic archive dress watches and updates the finishing for a slimmer, modern silhouette.",
    specs: [
      { label: "Case Diameter", value: "39 mm" },
      { label: "Movement", value: "Automatic, 40h reserve" },
      { label: "Water Resistance", value: "30 m" },
      { label: "Strap", value: "Genuine leather, tan" },
      { label: "Glass", value: "Sapphire crystal" }
    ]
  },
  {
    id: 6,
    name: "Steel Classic",
    category: "Quartz",
    price: 340,
    rating: 4,
    reviews: 64,
    image: "assets/images/watch-6.svg",
    tagline: "The one watch, if you're only buying one.",
    description:
      "A do-everything steel bracelet watch with a low-contrast dark dial. Understated enough for the office, sturdy enough for the weekend — the Steel Classic is the shape most people picture when they hear 'watch'.",
    specs: [
      { label: "Case Diameter", value: "40 mm" },
      { label: "Movement", value: "Precision quartz" },
      { label: "Water Resistance", value: "50 m" },
      { label: "Strap", value: "Stainless steel bracelet" },
      { label: "Glass", value: "Mineral crystal" }
    ]
  }
];

/** Build the star-rating markup, e.g. ★★★★☆ */
function starString(rating){
  const full = "★".repeat(rating);
  const empty = "☆".repeat(5 - rating);
  return full + empty;
}

/** Returns the HTML for one product card (used on Home + Collection). */
function productCardHTML(p){
  return `
    <article class="product-card" data-reveal>
      <a href="product.html?id=${p.id}" class="thumb" aria-label="View ${p.name}">
        <img src="${p.image}" alt="${p.name} watch" loading="lazy">
      </a>
      <div class="info">
        <span class="cat">${p.category}</span>
        <h3><a href="product.html?id=${p.id}">${p.name}</a></h3>
        <div class="stars" aria-label="${p.rating} out of 5 stars">${starString(p.rating)}</div>
        <div class="price">$${p.price}</div>
        <a href="product.html?id=${p.id}" class="btn btn-outline btn-sm">View Details</a>
      </div>
    </article>`;
}

/** Renders a list of products into a container element by id. */
function renderProductGrid(containerId, list){
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = list.map(productCardHTML).join("");
}

/** Reads ?id= from the URL and returns the matching product (or the first). */
function getProductFromURL(){
  const params = new URLSearchParams(window.location.search);
  const id = parseInt(params.get("id"), 10);
  return PRODUCTS.find(p => p.id === id) || PRODUCTS[0];
}
