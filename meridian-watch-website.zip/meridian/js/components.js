/* ============================================================
   MERIDIAN — Shared navbar & footer
   Injected into #site-navbar / #site-footer on every page so
   the markup only has to be edited in one place.
   ============================================================ */

const NAV_LINKS = [
  { href: "index.html", label: "Home" },
  { href: "collection.html", label: "Collection" },
  { href: "about.html", label: "About" },
  { href: "contact.html", label: "Contact" }
];

function currentPage(){
  const path = window.location.pathname.split("/").pop();
  return path === "" ? "index.html" : path;
}

function navbarHTML(){
  const page = currentPage();
  // product.html is a sub-page of the collection, so it should still
  // highlight "Collection" in the nav rather than showing nothing active.
  const activeHref = page === "product.html" ? "collection.html" : page;
  const links = NAV_LINKS.map(l =>
    `<a href="${l.href}" class="${l.href === activeHref ? "active" : ""}">${l.label}</a>`
  ).join("");

  return `
  <nav class="navbar">
    <div class="container">
      <a href="index.html" class="logo">MERI<span>DIAN</span></a>
      <div class="nav-links">${links}</div>
      <div class="nav-right">
        <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark and light mode">
          <span class="knob" id="themeKnob">☀️</span>
        </button>
        <button class="hamburger" id="hamburger" aria-label="Open menu" aria-expanded="false">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  </nav>
  <div class="mobile-menu" id="mobileMenu">
    ${NAV_LINKS.map(l => `<a href="${l.href}">${l.label}</a>`).join("")}
  </div>`;
}

function footerHTML(){
  return `
  <footer class="footer">
    <div class="container">
      <div class="footer-top">
        <div class="footer-brand">
          <a href="index.html" class="logo">MERI<span>DIAN</span></a>
          <p>Timeless design and modern precision, on your wrist since day one. Watches built to be worn, not just owned.</p>
          <div class="social-row">
            <a href="#" aria-label="Instagram">IG</a>
            <a href="#" aria-label="Facebook">FB</a>
            <a href="#" aria-label="Twitter / X">X</a>
            <a href="#" aria-label="Pinterest">P</a>
          </div>
        </div>
        <div>
          <h4>Quick Links</h4>
          <ul class="footer-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="collection.html">Collection</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4>Support</h4>
          <ul class="footer-links">
            <li><a href="contact.html">Contact Us</a></li>
            <li><a href="#">Shipping Info</a></li>
            <li><a href="#">Warranty</a></li>
            <li><a href="#">FAQs</a></li>
          </ul>
        </div>
        <div>
          <h4>Get In Touch</h4>
          <ul class="footer-links">
            <li><a href="mailto:hello@meridianwatches.com">hello@meridianwatches.com</a></li>
            <li><a href="tel:+922112345678">+92 21 1234 5678</a></li>
            <li><span class="muted">Karachi, Pakistan</span></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <span>&copy; <span id="year"></span> MERIDIAN Watches. All rights reserved.</span>
        <span>Designed for a university assignment.</span>
      </div>
    </div>
  </footer>
  <div class="toast" id="toast"></div>`;
}

document.addEventListener("DOMContentLoaded", () => {
  const navSlot = document.getElementById("site-navbar");
  const footerSlot = document.getElementById("site-footer");
  if(navSlot) navSlot.innerHTML = navbarHTML();
  if(footerSlot) footerSlot.innerHTML = footerHTML();

  const yearEl = document.getElementById("year");
  if(yearEl) yearEl.textContent = new Date().getFullYear();

  // Let main.js know the shared chrome now exists in the DOM.
  document.dispatchEvent(new Event("meridian:chrome-ready"));
});
