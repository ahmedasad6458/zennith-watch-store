/* ============================================================
   MERIDIAN — Interactions
   Theme toggle (localStorage) · mobile menu · scroll reveal ·
   subtle 3D tilt on hover · toast notifications.
   No backend, no build step — everything below is vanilla JS.
   ============================================================ */

const THEME_KEY = "meridian-theme";

function applyTheme(theme){
  document.documentElement.setAttribute("data-theme", theme);
  const knob = document.getElementById("themeKnob");
  if(knob) knob.textContent = theme === "dark" ? "🌙" : "☀️";
}

function initTheme(){
  const saved = localStorage.getItem(THEME_KEY);
  const prefersDark = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
  applyTheme(saved || (prefersDark ? "dark" : "light"));
}

function toggleTheme(){
  const current = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
  localStorage.setItem(THEME_KEY, next);
}

function initMobileMenu(){
  const btn = document.getElementById("hamburger");
  const menu = document.getElementById("mobileMenu");
  if(!btn || !menu) return;
  btn.addEventListener("click", () => {
    const isOpen = menu.classList.toggle("open");
    btn.classList.toggle("open", isOpen);
    btn.setAttribute("aria-expanded", String(isOpen));
    document.body.style.overflow = isOpen ? "hidden" : "";
  });
  menu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
    menu.classList.remove("open");
    btn.classList.remove("open");
    btn.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }));
}

function initScrollReveal(){
  const targets = document.querySelectorAll("[data-reveal]");
  if(!("IntersectionObserver" in window) || targets.length === 0){
    targets.forEach(t => t.classList.add("in-view"));
    return;
  }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add("in-view");
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: "0px 0px -60px 0px" });
  targets.forEach(t => io.observe(t));
}

/** Lightweight CSS-3D tilt: follows the cursor, resets on leave. */
function initTilt(){
  const els = document.querySelectorAll("[data-tilt]");
  els.forEach(el => {
    let frame = null;
    el.addEventListener("mousemove", (e) => {
      const rect = el.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      if(frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        el.style.transform = `perspective(1000px) rotateY(${x * 14}deg) rotateX(${y * -14}deg) scale3d(1.03,1.03,1.03)`;
      });
    });
    el.addEventListener("mouseleave", () => {
      el.style.transform = "perspective(1000px) rotateY(0deg) rotateX(0deg) scale3d(1,1,1)";
    });
  });
}

/** Simple hero parallax on mouse move — desktop only, very subtle. */
function initParallax(){
  const hero = document.querySelector(".hero-visual .ring");
  if(!hero || window.matchMedia("(max-width: 720px)").matches) return;
  window.addEventListener("mousemove", (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 14;
    const y = (e.clientY / window.innerHeight - 0.5) * 14;
    hero.style.marginLeft = `${x}px`;
    hero.style.marginTop = `${y}px`;
  });
}

let toastTimer = null;
function showToast(message){
  const toast = document.getElementById("toast");
  if(!toast) return;
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}

function initCartButtons(){
  document.querySelectorAll("[data-add-to-cart]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const name = btn.getAttribute("data-add-to-cart") || "Item";
      showToast(`Added "${name}" to cart`);
    });
  });
  document.querySelectorAll("[data-buy-now]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      showToast("This is a university assignment demo — checkout is not connected.");
    });
  });
}

function initContactForm(){
  const form = document.getElementById("contactForm");
  if(!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    showToast("Message sent — we'll get back to you soon.");
    form.reset();
  });
}

// Theme must apply immediately (before paint) to avoid a flash —
// handled by the inline script in <head>. This just wires the toggle.
document.addEventListener("meridian:chrome-ready", () => {
  initTheme();
  const toggle = document.getElementById("themeToggle");
  if(toggle) toggle.addEventListener("click", toggleTheme);
  initMobileMenu();
});

document.addEventListener("DOMContentLoaded", () => {
  initScrollReveal();
  initTilt();
  initParallax();
  initCartButtons();
  initContactForm();
});
